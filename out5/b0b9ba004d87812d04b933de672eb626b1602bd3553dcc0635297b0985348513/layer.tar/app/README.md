### CloudCats: Web

The CloudCats web process is responsible for serving front end web traffic.  It listens to a PubSub topic, and pipes results to the client via PubNub.  